#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════
  🎯  SOLANA SNIPER BOT — PAPER TRADING (ТОЛЬКО СИМУЛЯЦИЯ!)
═══════════════════════════════════════════════════════════════════════

  Скрипт слушает по WebSocket (WSS) создание новых монет/пулов на:
    • Pump.fun        (создание монет, инструкции create / create_v2)
    • Raydium AMM v4  (новые пулы, инструкция initialize2)
    • Raydium CPMM    (новые пулы, инструкции initialize / create_pool)
    • Meteora DLMM    (новые пулы, initializeLbPair*)
    • Meteora DAMM v1 (новые пулы, initialize)
    • Meteora DBC     (лончпад, initializeVirtualPool*)

  РЕЖИМ «ОДНА МОНЕТА» (по умолчанию):
    Бот ждёт ПЕРВУЮ монету, созданную после запуска, и работает только
    с ней: 🟢 фейк-покупка на 1500 ₽ → проверка цены каждые 5–10 секунд
    → 🔴 фейк-продажа при профите +50% / убытке −20% (или по таймауту)
    → показывает итоги и останавливается. Остальные новые монеты
    игнорируются.

  ПОИСК РЕАЛЬНОЙ ЦЕНЫ (без задержек индексаторов):
    1. Pump.fun — цена считается НАПРЯМУЮ из он-чейн бондинг-кривой
       (virtual_sol_reserves / virtual_token_reserves) — доступна
       сразу в момент создания монеты.
    2. DexScreener и GeckoTerminal — для пулов Raydium / Meteora
       (как только индексаторы их увидят).
    3. Симуляция случайного блуждания — только если ни один источник
       не дал цену (крайний случай).

  ⚠️  ВНИМАНИЕ: это СИМУЛЯТОР. Никаких реальных транзакций, приватных
      ключей и списаний здесь НЕТ и не может быть — только вывод в консоль.

  Запуск:
      pip install websockets aiohttp
      python solana_paper_sniper.py

  Настройка (необязательно, через переменные окружения):
      HELIUS_API_KEY=xxxx   свой ключ Helius (по умолчанию встроен ваш)
      DEPOSIT_RUB=1500      размер фейк-покупки в рублях
      TAKE_PROFIT_PCT=50    цель по прибыли, %
      STOP_LOSS_PCT=20      стоп по убытку, %
      MAX_HOLD_SEC=300      принудительная продажа по таймауту, секунд
"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import random
import re
import struct
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Set, Tuple

import aiohttp
import websockets

# ───────────────────────────── НАСТРОЙКИ ─────────────────────────────

# ⚠️ Ключ засвечен в переписке — после тестов выпустите новый в дашборде
# Helius и передайте его через переменную окружения HELIUS_API_KEY.
HELIUS_API_KEY = os.getenv("HELIUS_API_KEY", "af8a8d42-2f31-4262-8751-04a9f5c0b6a3")
WSS_URL = f"wss://mainnet.helius-rpc.com/?api-key={HELIUS_API_KEY}"
HTTP_RPC_URL = f"https://mainnet.helius-rpc.com/?api-key={HELIUS_API_KEY}"

DEPOSIT_RUB = float(os.getenv("DEPOSIT_RUB", "1500"))        # фейк-покупка, ₽
TAKE_PROFIT_PCT = float(os.getenv("TAKE_PROFIT_PCT", "50"))  # тейк-профит, %
STOP_LOSS_PCT = float(os.getenv("STOP_LOSS_PCT", "20"))      # стоп-лосс, %
CHECK_MIN_SEC = 5.0      # минимальная пауза между проверками цены
CHECK_MAX_SEC = 10.0     # максимальная пауза между проверками цены
MAX_HOLD_SEC = float(os.getenv("MAX_HOLD_SEC", "300"))  # принудительная продажа, с
PRICE_ATTEMPTS_AT_ENTRY = 3   # попыток узнать реальную цену при входе

DEXSCREENER_URL = "https://api.dexscreener.com/latest/dex/tokens/{mint}"
GECKOTERMINAL_URL = "https://api.geckoterminal.com/api/v2/networks/solana/tokens/{mint}/pools"
COINGECKO_SOL_URL = "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"

PUMP_PROGRAM_ID = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"

# ──────────────────── ПРОГРАММЫ И ФИЛЬТРЫ СОБЫТИЙ ────────────────────
# Каждой программе — своя подписка logsSubscribe(mentions=[program_id]).
# Событие «новая монета/пул» опознаётся по логам вида
#   "Program log: Instruction: <Create|Initialize2|InitializeLbPair|...>"

PROGRAMS: Dict[str, str] = {
    PUMP_PROGRAM_ID: "Pump.fun",
    "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8": "Raydium AMM v4",
    "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C": "Raydium CPMM",
    "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo": "Meteora DLMM",
    "Eo7WjKq67rjJQSZxS6z3YkapzY3eMj6Xy8X5EQVn5UaB": "Meteora DAMM v1",
    "dbcij3LWUppWqq96dh6gJWwBifmcGfLSB5D4DuSMaqN": "Meteora DBC",
}

CREATION_PATTERNS: Dict[str, List[re.Pattern]] = {
    # create и create_v2
    "Pump.fun": [re.compile(r"Instruction: Create(V2)?\b")],
    # новые AMM v4 пулы
    "Raydium AMM v4": [re.compile(r"Instruction: Initialize2\b")],
    # новые CPMM пулы (Anchor-лог: Initialize, лог IDL: create_pool)
    "Raydium CPMM": [
        re.compile(r"Instruction: Initialize\b"),
        re.compile(r"Instruction: CreatePool\b"),
    ],
    # initializeLbPair / initializeLbPair2 / Customizable / Permission
    "Meteora DLMM": [
        re.compile(r"Instruction: InitializeLbPair"),
        re.compile(r"Instruction: InitializeCustomizablePermissionlessLbPair"),
        re.compile(r"Instruction: InitializePermissionLbPair"),
    ],
    # legacy DAMM v1: initialize
    "Meteora DAMM v1": [re.compile(r"Instruction: Initialize\b")],
    # Dynamic Bonding Curve лончпад: initializeVirtualPool*
    "Meteora DBC": [re.compile(r"Instruction: InitializeVirtualPool")],
}

# ───────────────────────── ИЗВЕСТНЫЕ АДРЕСА ──────────────────────────

WSOL = "So11111111111111111111111111111111111111112"
USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
USDT = "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"
QUOTE_MINTS = {WSOL, USDC, USDT}

KNOWN_PROGRAMS: Set[str] = {
    "11111111111111111111111111111111",                          # System
    "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",              # SPL Token
    "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb",              # Token-2022
    "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL",             # Associated Token
    "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr",              # Memo
    "ComputeBudget111111111111111111111111111111",               # ComputeBudget
    "SysvarRent111111111111111111111111111111111",
    "SysvarC1ock11111111111111111111111111111111",
    "Ed25519SigVerify111111111111111111111111111",
    "KeccakSecp256k11111111111111111111111111111",
    "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s",              # Metaplex Metadata
    PUMP_PROGRAM_ID,
    "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA",              # PumpSwap
    "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8",
    "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C",
    "CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK",              # Raydium CLMM
    "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo",
    "Eo7WjKq67rjJQSZxS6z3YkapzY3eMj6Xy8X5EQVn5UaB",
    "dbcij3LWUppWqq96dh6gJWwBifmcGfLSB5D4DuSMaqN",
} | QUOTE_MINTS

# ─────────────────────────── СОСТОЯНИЕ ──────────────────────────────

seen_signatures: Set[str] = set()
seen_mints: Set[str] = set()
target_locked = False            # True — целевая монета уже выбрана (первая после запуска)
stop_event: Optional["asyncio.Event"] = None   # взводится после фейк-продажи
open_positions = 0
results: List[Tuple[float, float]] = []   # (pct, pnl_rub) по закрытым сделкам
background_tasks: Set["asyncio.Task[Any]"] = set()
_summary_printed = False
_sol_usd_cache: Tuple[float, Optional[float]] = (0.0, None)   # (timestamp, цена)


def spawn(coro) -> "asyncio.Task[Any]":
    """Запуск фоновой задачи с удержанием ссылки (защита от GC)."""
    task = asyncio.create_task(coro)
    background_tasks.add(task)
    task.add_done_callback(background_tasks.discard)
    return task


# ─────────────────────────── УТИЛИТЫ ────────────────────────────────


class Color:
    RESET = "\033[0m"
    DIM = "\033[2m"
    BOLD = "\033[1m"
    CYAN = "\033[36m"
    YELLOW = "\033[33m"
    MAGENTA = "\033[35m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    GRAY = "\033[90m"


def ts() -> str:
    return datetime.now().strftime("%H:%M:%S")


def log(msg: str, color: str = "") -> None:
    prefix = f"{Color.GRAY}[{ts()}]{Color.RESET}"
    print(f"{prefix} {color}{msg}{Color.RESET}", flush=True)


def short(addr: str, n: int = 4) -> str:
    return f"{addr[:n]}…{addr[-n:]}" if len(addr) > 2 * n + 1 else addr


def sim_next_price(price: float) -> float:
    """Случайное блуждание цены (крайний случай, когда нет ни одного источника)."""
    change = random.gauss(0.035, 0.12)
    return max(price * (1.0 + change), 1e-12)


# ─────────────── ПОИСК РЕАЛЬНОЙ ЦЕНЫ: ОН-ЧЕЙН PUMP.FUN ──────────────
# Бондинг-кривая Pump.fun хранит виртуальные резервы:
#   offset  8: virtual_token_reserves: u64
#   offset 16: virtual_sol_reserves:   u64
#   offset 48: complete: bool  (True = монета мигрировала на DEX)
# Цена в SOL = (virtual_sol / 1e9) / (virtual_token / 1e6).
# Это работает СРАЗУ при создании монеты — без ожидания индексаторов.


async def rpc_get_account_raw(
    session: aiohttp.ClientSession, address: str
) -> Optional[bytes]:
    """Сырые байты аккаунта (base64), None если аккаунта нет/ошибка."""
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getAccountInfo",
        "params": [address, {"encoding": "base64", "commitment": "processed"}],
    }
    try:
        async with session.post(
            HTTP_RPC_URL, json=payload, timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            data = await resp.json()
        value = ((data.get("result") or {}).get("value")) or {}
        raw = value.get("data") or []
        if not raw:
            return None
        return base64.b64decode(raw[0])
    except Exception:
        return None


async def find_curve_owner(
    session: aiohttp.ClientSession, mint: str
) -> Optional[str]:
    """Владелец крупнейшего токен-аккаунта = бондинг-кривая Pump.fun."""
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getTokenLargestAccounts",
        "params": [mint, {"commitment": "processed"}],
    }
    try:
        async with session.post(
            HTTP_RPC_URL, json=payload, timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            data = await resp.json()
        value = (data.get("result") or {}).get("value") or []
        if not value:
            return None
        token_account = value[0].get("address")
    except Exception:
        return None

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getAccountInfo",
        "params": [token_account, {"encoding": "jsonParsed", "commitment": "processed"}],
    }
    try:
        async with session.post(
            HTTP_RPC_URL, json=payload, timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            data = await resp.json()
        value = ((data.get("result") or {}).get("value")) or {}
        return (((value.get("data") or {}).get("parsed") or {}).get("info") or {}).get("owner")
    except Exception:
        return None


async def pump_curve_price_usd(
    session: aiohttp.ClientSession, mint: str, curve: Optional[str]
) -> Optional[float]:
    """Реальная цена Pump.fun из он-чейн бондинг-кривой, в USD."""
    if not curve:
        curve = await find_curve_owner(session, mint)
    if not curve:
        return None

    raw = await rpc_get_account_raw(session, curve)
    if not raw or len(raw) < 48:
        return None

    vtok, vsol = struct.unpack_from("<QQ", raw, 8)
    complete = bool(raw[48]) if len(raw) > 48 else False
    if complete or vtok == 0:
        return None  # мигрировала с кривой — дальше по индексаторам

    price_sol = (vsol / 1e9) / (vtok / 1e6)
    sol_usd = await get_sol_usd(session)
    if not sol_usd:
        return None
    return price_sol * sol_usd


async def get_sol_usd(session: aiohttp.ClientSession) -> Optional[float]:
    """Курс SOL/USD с кэшем на 60 с (DexScreener → CoinGecko)."""
    global _sol_usd_cache
    now = time.time()
    cached_at, cached = _sol_usd_cache
    if cached and now - cached_at < 60.0:
        return cached

    price: Optional[float] = None
    try:
        async with session.get(
            DEXSCREENER_URL.format(mint=WSOL),
            timeout=aiohttp.ClientTimeout(total=6),
        ) as resp:
            if resp.status == 200:
                pairs = ((await resp.json()).get("pairs")) or []

                def usd_per_sol(p: Dict[str, Any]) -> Tuple[float, float]:
                    try:
                        liq = float(((p.get("liquidity") or {}).get("usd")) or 0.0)
                        px = float(p.get("priceUsd") or 0.0)
                    except (TypeError, ValueError):
                        return (0.0, 0.0)
                    return (liq, px)

                best = max(pairs, key=usd_per_sol, default={})
                px = usd_per_sol(best)[1]
                if px > 0:
                    price = px
    except Exception:
        pass

    if not price:
        try:
            async with session.get(
                COINGECKO_SOL_URL, timeout=aiohttp.ClientTimeout(total=6)
            ) as resp:
                if resp.status == 200:
                    price = float((await resp.json())["solana"]["usd"])
        except Exception:
            pass

    if price:
        _sol_usd_cache = (now, price)
    return price


# ─────────── ПОИСК РЕАЛЬНОЙ ЦЕНЫ: DEX-ИНДЕКСАТОРЫ ───────────────────
# Используются для пулов Raydium / Meteora (и как запасной вариант).


async def fetch_dexscreener_price_usd(
    session: aiohttp.ClientSession, mint: str
) -> Optional[float]:
    """Цена из пары с максимальной ликвидностью на DexScreener."""
    try:
        async with session.get(
            DEXSCREENER_URL.format(mint=mint),
            timeout=aiohttp.ClientTimeout(total=6),
        ) as resp:
            if resp.status != 200:
                return None
            pairs = (await resp.json()).get("pairs") or []
    except Exception:
        return None
    if not pairs:
        return None

    def liquidity(p: Dict[str, Any]) -> float:
        try:
            return float(((p.get("liquidity") or {}).get("usd")) or 0.0)
        except (TypeError, ValueError):
            return 0.0

    best = max(pairs, key=liquidity)
    try:
        price = float(best.get("priceUsd") or 0.0)
    except (TypeError, ValueError):
        return None
    return price if price > 0 else None


async def fetch_geckoterminal_price_usd(
    session: aiohttp.ClientSession, mint: str
) -> Optional[float]:
    """Цена из пулов токена на GeckoTerminal (запасной индексатор)."""
    try:
        async with session.get(
            GECKOTERMINAL_URL.format(mint=mint),
            headers={"Accept": "application/json"},
            timeout=aiohttp.ClientTimeout(total=6),
        ) as resp:
            if resp.status != 200:
                return None
            pools = (await resp.json()).get("data") or []
    except Exception:
        return None
    if not pools:
        return None

    def reserve(p: Dict[str, Any]) -> float:
        try:
            return float(((p.get("attributes") or {}).get("reserve_in_usd")) or 0.0)
        except (TypeError, ValueError):
            return 0.0

    best_attrs = (max(pools, key=reserve).get("attributes")) or {}
    price: Optional[float] = None
    try:
        if best_attrs.get("base_token_address") == mint:
            price = float(best_attrs.get("base_token_price_usd") or 0.0)
        elif best_attrs.get("quote_token_address") == mint:
            price = float(best_attrs.get("quote_token_price_usd") or 0.0)
        else:
            price = float(best_attrs.get("base_token_price_usd") or 0.0)
    except (TypeError, ValueError):
        return None
    return price if price and price > 0 else None


async def resolve_real_price(
    session: aiohttp.ClientSession, mint: str, source: str, curve: Optional[str]
) -> Tuple[Optional[float], str]:
    """
    Полная цепочка поиска реальной цены.
    Возвращает (цена_usd, имя_источника) или (None, "").
    """
    if source == "Pump.fun":
        price = await pump_curve_price_usd(session, mint, curve)
        if price:
            return price, "он-чейн кривая"

    price = await fetch_dexscreener_price_usd(session, mint)
    if price:
        return price, "DexScreener"

    price = await fetch_geckoterminal_price_usd(session, mint)
    if price:
        return price, "GeckoTerminal"

    return None, ""


# ─────────────────── ИЗВЛЕЧЕНИЕ MINT ИЗ ТРАНЗАКЦИИ ──────────────────


def mint_from_token_balances(tx: Dict[str, Any]) -> Optional[Tuple[str, Optional[str]]]:
    """
    Монета с наибольшим «сырым» балансом среди не-котируемых
    (не SOL/USDC/USDT). Попутно возвращаем владельца токен-аккаунта —
    для Pump.fun это и есть бондинг-кривая (адрес для он-чейн цены).
    """
    meta = tx.get("meta") or {}
    amounts: Dict[str, Tuple[int, str]] = {}
    balances = (meta.get("postTokenBalances") or []) + (meta.get("preTokenBalances") or [])
    for bal in balances:
        mint = bal.get("mint")
        if not mint or mint in QUOTE_MINTS:
            continue
        try:
            amt = int(((bal.get("uiTokenAmount") or {}).get("amount")) or 0)
        except (TypeError, ValueError):
            amt = 0
        owner = bal.get("owner") or ""
        prev = amounts.get(mint, (0, ""))
        if amt >= prev[0]:
            amounts[mint] = (amt, owner)
    if not amounts:
        return None
    best_mint, (best_amt, best_owner) = max(amounts.items(), key=lambda kv: kv[1][0])
    return best_mint, (best_owner or None)


async def mint_from_account_scan(
    session: aiohttp.ClientSession, tx: Dict[str, Any]
) -> Optional[Tuple[str, Optional[str]]]:
    """
    Запасной путь: перебираем аккаунты транзакции и оставляем настоящие
    mint-аккаунты (проверка getMultipleAccounts, parsed.type == 'mint').
    Из кандидатов выбираем первый не-котируемый.
    """
    message = (tx.get("transaction") or {}).get("message") or {}
    keys = [k.get("pubkey") if isinstance(k, dict) else k for k in (message.get("accountKeys") or [])]
    candidates = [k for k in keys if k and k not in KNOWN_PROGRAMS and len(k) >= 32]
    if not candidates:
        return None

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getMultipleAccounts",
        "params": [candidates[:30], {"encoding": "jsonParsed"}],
    }
    try:
        async with session.post(
            HTTP_RPC_URL, json=payload, timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            data = await resp.json()
    except Exception:
        return None

    mints: List[str] = []
    for item in (data.get("result") or {}).get("value") or []:
        if not item:
            continue
        parsed = ((item.get("data") or {}).get("parsed")) or {}
        if parsed.get("type") == "mint":
            mints.append(item.get("pubkey") or "")
    mints = [m for m in mints if m]
    if not mints:
        return None
    non_quote = [m for m in mints if m not in QUOTE_MINTS]
    return (non_quote or mints)[0], None


async def fetch_mint_from_signature(
    session: aiohttp.ClientSession, signature: str
) -> Optional[Tuple[str, Optional[str]]]:
    """getTransaction(jsonParsed) + разбор mint с повторными попытками."""
    for attempt in range(5):
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getTransaction",
            "params": [
                signature,
                {
                    "encoding": "jsonParsed",
                    "maxSupportedTransactionVersion": 0,
                    "commitment": "confirmed",
                },
            ],
        }
        tx = None
        try:
            async with session.post(
                HTTP_RPC_URL, json=payload, timeout=aiohttp.ClientTimeout(total=15)
            ) as resp:
                if resp.status == 429:  # rate limit Helius — ждём дольше
                    await asyncio.sleep(3.0 * (attempt + 1))
                    continue
                data = await resp.json()
            tx = data.get("result")
        except Exception:
            tx = None

        if tx:
            found = mint_from_token_balances(tx)
            if found:
                return found
            found = await mint_from_account_scan(session, tx)
            if found:
                return found
            return None  # транзакция есть, но mint не нашли — не ретраим

        await asyncio.sleep(1.5 * (attempt + 1) + random.uniform(0, 0.5))
    return None


# ───────────────────────── PAPER TRADING ────────────────────────────


@dataclass
class Position:
    mint: str
    source: str
    entry_price: float
    simulated: bool          # True = цена пока симулируется (нет ни одного источника)
    opened_at: float
    deposit_rub: float
    curve: Optional[str] = None       # бондинг-кривая Pump.fun (для он-чейн цены)
    price_origin: str = ""            # откуда получена текущая цена


async def manage_position(session: aiohttp.ClientSession, pos: Position) -> None:
    """Цикл проверок цены: тейк +50%, стоп −20%, принудительный выход по таймауту."""
    global open_positions
    try:
        while True:
            delay = random.uniform(CHECK_MIN_SEC, CHECK_MAX_SEC)
            await asyncio.sleep(delay)

            held = time.time() - pos.opened_at
            real, origin = await resolve_real_price(session, pos.mint, pos.source, pos.curve)

            if pos.simulated:
                # Пока ни один источник не знает монету — цена симулируется.
                # Как только реальная цена найдена — переходим на неё.
                if real:
                    pos.entry_price = real
                    pos.simulated = False
                    pos.price_origin = origin
                    log(
                        f"🔄 {short(pos.mint)}: найдена реальная цена ({origin}) — "
                        f"база ${real:.10g}",
                        Color.CYAN,
                    )
                    price = real
                else:
                    price = sim_next_price(pos.entry_price)
            else:
                if real is None:
                    log(
                        f"⏳ {short(pos.mint)}: цена недоступна — ждём… "
                        f"{held:.0f}с в позиции",
                        Color.DIM,
                    )
                    if held >= MAX_HOLD_SEC:
                        await close_position(pos, pos.entry_price, reason="таймаут, цены не было")
                        return
                    continue
                price = real
                pos.price_origin = origin

            pct = (price / pos.entry_price - 1.0) * 100.0
            tag = "СИМ" if pos.simulated else (pos.price_origin or "РЕАЛ")
            log(
                f"⏳ [{tag}] {short(pos.mint)} ({pos.source}) "
                f"цена ${price:.10g} → {pct:+.1f}% от входа | {held:.0f}с",
                Color.DIM,
            )

            if pct >= TAKE_PROFIT_PCT:
                await close_position(pos, price, reason="тейк-профит")
                return
            if pct <= -STOP_LOSS_PCT:
                await close_position(pos, price, reason="стоп-лосс")
                return
            if held >= MAX_HOLD_SEC:
                await close_position(pos, price, reason="таймаут")
                return
    except asyncio.CancelledError:
        raise
    finally:
        open_positions -= 1


async def close_position(pos: Position, exit_price: float, reason: str) -> None:
    pct = (exit_price / pos.entry_price - 1.0) * 100.0
    pnl_rub = pos.deposit_rub * pct / 100.0
    results.append((pct, pnl_rub))

    if pct >= 0:
        log(
            f"🔴 ФЕЙК ПРОДАЖА! Итог: +{pct:.1f}% (Прибыль: {pnl_rub:.2f} руб)",
            Color.GREEN + Color.BOLD,
        )
    else:
        log(
            f"🔴 ФЕЙК ПРОДАЖА! Итог: -{abs(pct):.1f}% (Убыток: {abs(pnl_rub):.2f} руб)",
            Color.RED + Color.BOLD,
        )
    log(
        f"   {Color.DIM}mint: {pos.mint} | {pos.source} | вход ${pos.entry_price:.10g} → "
        f"выход ${exit_price:.10g} | {reason} | держали "
        f"{time.time() - pos.opened_at:.0f}с{Color.RESET}",
        Color.GRAY,
    )

    # Режим одной монеты: сделка закрыта — показываем итоги и выходим.
    log("🏁 Сделка по целевой монете закрыта — завершаем работу", Color.CYAN)
    if stop_event is not None:
        stop_event.set()


async def start_paper_trade(
    session: aiohttp.ClientSession, mint: str, source: str, curve: Optional[str]
) -> None:
    """Симуляция покупки на DEPOSIT_RUB ₽ и запуск менеджера позиции."""
    global open_positions

    # Ищем реальную цену входа: он-чейн кривая (Pump.fun) → DexScreener →
    # GeckoTerminal. Только если ничего не нашли — симуляция.
    entry_price: Optional[float] = None
    entry_origin = ""
    for attempt in range(PRICE_ATTEMPTS_AT_ENTRY):
        entry_price, entry_origin = await resolve_real_price(session, mint, source, curve)
        if entry_price:
            break
        await asyncio.sleep(2.0)

    simulated = entry_price is None
    if simulated:
        entry_price = random.uniform(1e-8, 1e-4)  # стартовая цена-заглушка
        log(
            f"⚠️  {short(mint)}: цена не найдена ни в одном источнике — "
            f"симулируем стартовую цену ${entry_price:.10g}",
            Color.YELLOW,
        )

    open_positions += 1
    pos = Position(
        mint=mint,
        source=source,
        entry_price=entry_price,
        simulated=simulated,
        opened_at=time.time(),
        deposit_rub=DEPOSIT_RUB,
        curve=curve,
        price_origin=entry_origin or ("СИМ" if simulated else ""),
    )

    log(
        f"🟢 ФЕЙК ПОКУПКА монеты {mint} на {DEPOSIT_RUB:.0f} рублей",
        Color.GREEN + Color.BOLD,
    )
    log(
        f"   {Color.DIM}источник: {source} | вход: ${entry_price:.10g}"
        f"{f' ({entry_origin})' if entry_origin else ''} | "
        f"цель: +{TAKE_PROFIT_PCT:.0f}% / стоп: -{STOP_LOSS_PCT:.0f}% | "
        f"проверка цены каждые {CHECK_MIN_SEC:.0f}–{CHECK_MAX_SEC:.0f}с{Color.RESET}",
        Color.GRAY,
    )

    spawn(manage_position(session, pos))


# ─────────────────────── ОБРАБОТКА WS-СОБЫТИЙ ───────────────────────


async def on_logs(session: aiohttp.ClientSession, result: Dict[str, Any], source: str) -> None:
    global seen_signatures, seen_mints, target_locked

    if target_locked:
        return  # режим одной монеты: целевая монета уже выбрана

    if result.get("err") is not None:
        return

    signature = result.get("signature")
    logs: List[str] = result.get("logs") or []

    patterns = CREATION_PATTERNS.get(source) or []
    is_creation = any(p.search(line) for line in logs for p in patterns)
    if not is_creation:
        return

    if signature in seen_signatures:
        return
    seen_signatures.add(signature)
    if len(seen_signatures) > 50_000:
        seen_signatures.clear()

    log(f"🔎 Создание монеты/пула! {source} | tx {short(signature, 8)}", Color.CYAN)

    found = await fetch_mint_from_signature(session, signature)
    if not found:
        log(f"   {Color.DIM}не удалось извлечь mint из транзакции — ждём следующую{Color.RESET}", Color.GRAY)
        return

    mint, owner = found
    # Для Pump.fun владелец токен-аккаунта из create-транзакции —
    # это и есть бондинг-кривая (для мгновенного он-чейн прайса).
    curve = owner if source == "Pump.fun" else None

    # Атомарно захватываем цель (между проверкой и присвоением нет await —
    # конкурирующие обработчики не смогут взять вторую монету).
    if target_locked or mint in seen_mints:
        return
    seen_mints.add(mint)
    target_locked = True

    log(f"🎯 ЦЕЛЕВАЯ МОНЕТА: {mint} ({source}) — работаем только с ней", Color.MAGENTA + Color.BOLD)
    await start_paper_trade(session, mint, source, curve)


async def ws_listener(session: aiohttp.ClientSession) -> None:
    """Подключение к WSS, подписки logsSubscribe, авто-переподключение."""
    backoff = 1.0
    while True:
        try:
            async with websockets.connect(
                WSS_URL,
                ping_interval=20,
                ping_timeout=20,
                close_timeout=5,
                max_size=2 ** 23,
            ) as ws:
                log("✅ WebSocket подключён. Подписываемся на программы…", Color.GREEN)

                pending: Dict[int, str] = {}
                sub_names: Dict[int, str] = {}
                for req_id, (program_id, name) in enumerate(PROGRAMS.items(), start=1):
                    await ws.send(
                        json.dumps(
                            {
                                "jsonrpc": "2.0",
                                "id": req_id,
                                "method": "logsSubscribe",
                                "params": [
                                    {"mentions": [program_id]},
                                    {"commitment": "processed"},
                                ],
                            }
                        )
                    )
                    pending[req_id] = name

                backoff = 1.0  # соединение живое — сбрасываем бэкофф

                async for raw in ws:
                    msg = json.loads(raw)

                    # Ответ на подписку: {"id": N, "result": <sub_id>}
                    req_id = msg.get("id")
                    if req_id in pending and "result" in msg:
                        sub_names[msg["result"]] = pending.pop(req_id)
                        if not pending:
                            log(
                                f"📡 Активных подписок: {len(sub_names)} — "
                                f"{', '.join(sub_names.values())}",
                                Color.GREEN,
                            )
                        continue

                    if msg.get("method") != "logsNotification":
                        continue

                    params = msg.get("params") or {}
                    source = sub_names.get(params.get("subscription"), "Unknown")
                    # Solana-нотификации завёрнуты в {context, value}
                    result = params.get("result") or {}
                    if "value" in result:
                        result = result.get("value") or {}
                    spawn(on_logs(session, result, source))

        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log(f"❌ WebSocket ошибка: {exc}", Color.RED)
            log(f"↻ Переподключение через {backoff:.0f} с…", Color.YELLOW)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60.0)


# ─────────────────────────────── MAIN ───────────────────────────────


def print_banner() -> None:
    os.system("")  # включает ANSI-цвета в современных Windows-терминалах
    print(
        f"""
{Color.CYAN}{Color.BOLD}╔══════════════════════════════════════════════════════════════╗
║   🎯  SOLANA SNIPER BOT — PAPER TRADING (без реальных сделок)  ║
╚══════════════════════════════════════════════════════════════╝{Color.RESET}
  {Color.DIM}Слушаем создание монет: Pump.fun · Raydium AMM v4 / CPMM · Meteora DLMM / DAMM v1 / DBC{Color.RESET}
  {Color.DIM}Цена: он-чейн кривая Pump.fun → DexScreener → GeckoTerminal → симуляция{Color.RESET}

  🎯 Режим:            {Color.BOLD}ОДНА МОНЕТА — первая созданная после запуска{Color.RESET}
  {Color.DIM}после фейк-продажи бот покажет итоги и остановится{Color.RESET}
  💰 Фейк-покупка:      {Color.BOLD}{DEPOSIT_RUB:.0f} ₽{Color.RESET}
  🎯 Тейк / стоп:       {Color.BOLD}+{TAKE_PROFIT_PCT:.0f}% / -{STOP_LOSS_PCT:.0f}%{Color.RESET}
  ⏱  Проверка цены:     каждые {CHECK_MIN_SEC:.0f}–{CHECK_MAX_SEC:.0f} с
  {Color.DIM}Ctrl+C — остановить в любой момент{Color.RESET}
"""
    )


def print_summary() -> None:
    global _summary_printed
    if _summary_printed:
        return
    _summary_printed = True
    total = len(results)
    if total == 0:
        log("Итогов нет — фейк-сделок не было.", Color.YELLOW)
        return
    wins = sum(1 for pct, _ in results if pct >= 0)
    total_pnl = sum(pnl for _, pnl in results)
    best = max(results, key=lambda r: r[0])
    worst = min(results, key=lambda r: r[0])
    color = Color.GREEN if total_pnl >= 0 else Color.RED
    print(f"\n{Color.BOLD}═════════ ИТОГИ ФЕЙК-ТОРГОВЛИ ═════════{Color.RESET}")
    print(f"  Сделок:            {total}")
    print(f"  Прибыльных:        {wins}")
    print(f"  Убыточных:         {total - wins}")
    print(f"  Лучшая:            {best[0]:+.1f}%")
    print(f"  Худшая:            {worst[0]:+.1f}%")
    print(f"  Общий фейк-PnL:    {color}{total_pnl:+.2f} руб{Color.RESET}")
    print(f"  {Color.DIM}Симуляция. Реальных денег не задействовано.{Color.RESET}\n")


async def main() -> None:
    global stop_event
    print_banner()
    stop_event = asyncio.Event()
    connector = aiohttp.TCPConnector(limit=100, ttl_dns_cache=300)
    async with aiohttp.ClientSession(connector=connector) as session:
        listener = spawn(ws_listener(session))
        # Работаем до фейк-продажи целевой монеты (или до Ctrl+C)
        await stop_event.wait()
        log("⏹ Останавливаем WebSocket и фоновые задачи…", Color.DIM)
        listener.cancel()
        for task in list(background_tasks):
            task.cancel()
        await asyncio.gather(listener, *background_tasks, return_exceptions=True)
    print_summary()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n")
        print_summary()
        sys.exit(0)

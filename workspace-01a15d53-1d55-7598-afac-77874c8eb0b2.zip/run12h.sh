#!/bin/bash
# 12 прогонов по 60 минут, каждый — конфиг с лучшими шансами на профит.
#
# ЖИЗНЕОБЕСПЕЧЕНИЕ: бот пишет все файлы в /tmp/live_run (вне /home/user).
# Песочница на старте каждого хода восстанавливает снапшот /home/user и
# «выпиливает» каталог, в котором бот сидит — тогда все create/open('w')
# падают с FileNotFoundError и бот превращается в зомби. /tmp рестор не трогает.
# Каждые 8 секунд фоновая петля копирует живые файлы в runs/sync/ (на случай
# смерти песочницы), а в конце прогона всё архивируется в runs/<N>-<label>/.
#
# Режим докрутки: готовые прогоны (runs/<N>-<label>/ уже есть) пропускаются.
set -euo pipefail
cd /home/user/solana_sniper
mkdir -p runs /tmp/live_run

# Окружение может начинаться без пользовательских пакетов; установим их до матрицы.
if ! python3 -c 'import websockets, aiohttp, aiosqlite' >/dev/null 2>&1; then
    echo 'Зависимости отсутствуют — устанавливаю requirements.txt'
    python3 -m pip install --user -r requirements.txt
fi

# Максимальная длительность любой позиции во всех A/B-конфигах.
export MAX_HOLD_SEC=120

# --- синхронизацию ведёт отдельный процесс sync.sh (живёт независимо) ---

i=0
run() {  # $1 = метка, остальные = VAR=VAL
    i=$((i+1))
    local label="$1"; shift
    if [ -f "runs/$i-$label/sniper.db" ] || [ -f "runs/$i-$label/wallet.json" ]; then
        echo "===== ПРОГОН $i/12 [$label] УЖЕ ГОТОВ — пропускаю ====="
        return 0
    fi
    echo "===== ПРОГОН $i/12 [$label] старт $(date +%H:%M:%S) ====="
    rm -f /tmp/live_run/*
    local rc=0
    ( cd /tmp/live_run && env "$@" MODE=portfolio \
        WALLET_PATH=/tmp/live_run/wallet.json \
        TRADE_LOG=/tmp/live_run/trades.log \
        DB_PATH=/tmp/live_run/sniper.db \
        timeout --signal=INT 3605 \
        python3 -u /home/user/solana_sniper/main.py > /tmp/live_run/console.log 2>&1 ) || rc=$?
    if [ "$rc" -ne 0 ] && [ "$rc" -ne 124 ]; then
        echo "ОШИБКА: прогон $i [$label] завершился с кодом $rc; не архивирую как готовый."
        return "$rc"
    fi
    mkdir -p "runs/$i-$label"
    for f in console.log sniper.db wallet.json trades.log; do
        [ -f "/tmp/live_run/$f" ] && cp -f "/tmp/live_run/$f" "runs/$i-$label/$f"
    done
    echo "===== ПРОГОН $i/12 [$label] финиш $(date +%H:%M:%S) ====="
    echo "$i $label $(date +%H:%M:%S)" >> runs/progress.txt
    sleep 5
}

# --- Семейство A: «ракетопил» — давать выигрышам расти ---
run rocket   TAKE_PROFIT_PCT=50 TRAIL_PCT=25 STAGNATION_SEC=300 BE_OFFSET_PCT=10 STOP_LOSS_PCT=15 ENTRY_FEE_SOL=0.001
run rocket2  TAKE_PROFIT_PCT=40 TRAIL_PCT=20 STAGNATION_SEC=240 BE_OFFSET_PCT=7  STOP_LOSS_PCT=12 ENTRY_FEE_SOL=0.0005
# Конфиг 3 — защитный профиль по текущим наблюдениям; таймер застоя 60с.
run ideal60  TAKE_PROFIT_PCT=35 TRAIL_PCT=18 STAGNATION_SEC=60 STAGNATION_RANGE_PCT=2 BE_OFFSET_PCT=6 STOP_LOSS_PCT=10 ENTRY_FEE_SOL=0.0005 MAX_POSITIONS=2 MIN_LIQUIDITY_USD=3000 CHECK_MIN_SEC=0.5 CHECK_MAX_SEC=0.5

# --- Семейство B: качество входа (меньше сделок, но живее) ---
run quality1 MIN_LIQUIDITY_USD=3000 STAGNATION_SEC=240 TAKE_PROFIT_PCT=40 TRAIL_PCT=20 ENTRY_FEE_SOL=0.001
run quality2 MIN_LIQUIDITY_USD=5000 STAGNATION_SEC=300 TAKE_PROFIT_PCT=50 TRAIL_PCT=25 ENTRY_FEE_SOL=0.001
run quality3 MIN_LIQUIDITY_USD=2000 STAGNATION_SEC=240 TAKE_PROFIT_PCT=40 TRAIL_PCT=20 MAX_POSITIONS=2 ENTRY_FEE_SOL=0.001

# --- Семейство C: баланс ---
run balanced TAKE_PROFIT_PCT=40 STOP_LOSS_PCT=12 BE_OFFSET_PCT=5 TRAIL_PCT=18 STAGNATION_SEC=240 ENTRY_FEE_SOL=0.001
run tight    TAKE_PROFIT_PCT=35 STOP_LOSS_PCT=8  BE_OFFSET_PCT=3 TRAIL_PCT=12 STAGNATION_SEC=180 ENTRY_FEE_SOL=0.0005
run patient  TAKE_PROFIT_PCT=45 STOP_LOSS_PCT=12 BE_OFFSET_PCT=8 TRAIL_PCT=22 STAGNATION_SEC=360 ENTRY_FEE_SOL=0.001

# --- Семейство D: комиссии/слоты на лучшем семействе ---
run nofee    TAKE_PROFIT_PCT=45 STAGNATION_SEC=240 TRAIL_PCT=22 STOP_LOSS_PCT=12 ENTRY_FEE_SOL=0.0005 MAX_POSITIONS=2
run slots4   TAKE_PROFIT_PCT=40 STAGNATION_SEC=240 TRAIL_PCT=20 STOP_LOSS_PCT=12 ENTRY_FEE_SOL=0.0005 MAX_POSITIONS=4
run champion TAKE_PROFIT_PCT=50 STOP_LOSS_PCT=12 BE_OFFSET_PCT=8 TRAIL_PCT=22 STAGNATION_SEC=300 ENTRY_FEE_SOL=0.0005 MIN_LIQUIDITY_USD=2500

echo "ВСЕ 12 ПРОГОНОВ ЗАВЕРШЕНЫ $(date +%H:%M:%S)"

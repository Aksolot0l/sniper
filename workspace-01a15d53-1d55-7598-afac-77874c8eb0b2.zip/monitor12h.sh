#!/usr/bin/env bash
set -euo pipefail

# Сохраняем дашборд каждые 5 минут, чтобы результаты пережили перезапуск среды.
out=/home/user/solana_sniper/runs/monitor
mkdir -p "$out"
for ((i=1; i<=144; i++)); do
    stamp=$(date -u +%Y%m%dT%H%M%SZ)
    bash /home/user/watch.sh > "$out/$stamp.txt" 2>&1 || true
    printf '%s snapshot=%s\n' "$(date -u '+%F %T')" "$stamp" >> "$out/index.log"
    sleep 300
done

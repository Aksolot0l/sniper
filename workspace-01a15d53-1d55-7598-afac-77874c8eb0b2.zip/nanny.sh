#!/bin/bash
# Няня: спасает живые файлы бота из /proc/PID/fd.
# Проблема: при старте каждого хода песочница восстанавливает снапшот
# и «выпиливает» файлы, в которые бот пишет (лог и sqlite).
# Бот продолжает писать в удалённый inode — данные видны только через
# /proc/PID/fd. Няня каждые 8 секунд копирует их обратно на диск,
# чтобы снапшот на конце хода забирал свежие данные.
while true; do
  pid=$(pgrep -f 'python3 -u main.py' | head -1)
  if [ -n "$pid" ] && [ -d "/proc/$pid/fd" ]; then
    for n in $(ls "/proc/$pid/fd" 2>/dev/null); do
      t=$(readlink "/proc/$pid/fd/$n" 2>/dev/null) || continue
      t="${t% (deleted)}"
      case "$t" in
        */console_*.log)
          cp -f "/proc/$pid/fd/$n" "$t.tmp" 2>/dev/null && mv -f "$t.tmp" "$t" 2>/dev/null ;;
        */sniper.db)
          cp -f "/proc/$pid/fd/$n" "/home/user/solana_sniper/sniper.db.tmp" 2>/dev/null \
            && mv -f "/home/user/solana_sniper/sniper.db.tmp" "/home/user/solana_sniper/sniper.db" 2>/dev/null ;;
      esac
    done
  fi
  sleep 8
done

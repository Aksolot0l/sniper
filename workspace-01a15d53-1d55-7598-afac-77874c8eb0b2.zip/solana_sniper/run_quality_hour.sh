#!/usr/bin/env bash
set -uo pipefail

PROJECT='/home/user/solana_sniper'
RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
WORK="/tmp/quality-rocket2-$RUN_ID"
LIVE="$PROJECT/runs/quality-rocket2-live"
ARCHIVE="$PROJECT/runs/quality-rocket2-$RUN_ID"
CURRENT="$PROJECT/runs/quality-rocket2-current.env"

cd "$PROJECT"
mkdir -p "$PROJECT/runs"

# Не допускаем второй торговый процесс или старый матричный runner.
if pgrep -af '[p]ython3 -u /home/user/solana_sniper/main.py' >/dev/null; then
    echo 'ERROR: найден другой main.py; второй paper-прогон не запускаю.'
    exit 2
fi
if pgrep -af '[b]ash /home/user/run12h.sh|[b]ash /home/user/solana_sniper/run12h.sh' >/dev/null; then
    echo 'ERROR: найден активный matrix-runner; новый прогон не запускаю.'
    exit 3
fi
if pgrep -af '[b]ash /home/user/sync.sh' >/dev/null; then
    echo 'ERROR: найден старый sync.sh; сначала остановить его.'
    exit 3
fi

exec 9>"$PROJECT/runs/quality-rocket2.lock"
if ! flock -n 9; then
    echo 'ERROR: quality-rocket2 runner уже использует lock.'
    exit 4
fi

# Все проверки и зависимости — до старта часового окна.
if ! python3 -c 'import websockets, aiohttp, aiosqlite' >/dev/null 2>&1; then
    echo 'ERROR: зависимости не установлены; прогон не стартовал.'
    exit 5
fi
python3 -m py_compile config.py filters.py trader.py main.py detector.py || exit 6
python3 -m unittest discover -s tests -v || exit 7

# Новый quality-профиль: параметры выхода взяты из наименее убыточного
# чистого часового теста rocket2; качество входа ужесточено по итогам realism.
export MODE='portfolio'
export DEPOSIT_RUB='1500'
export MAX_HOLD_SEC='120'
export TAKE_PROFIT_PCT='40'
export TRAIL_PCT='20'
export STAGNATION_SEC='240'
export STAGNATION_RANGE_PCT='3'
export BE_OFFSET_PCT='7'
export STOP_LOSS_PCT='12'
export ENTRY_FEE_SOL='0.0005'
export EXIT_FEE_SOL='0.0001'
export PROTOCOL_FEE_PCT='1.25'
export USD_RUB_RATE='90'
export MAX_TRADE_RUB='1500'
export MAX_POSITIONS='1'
export MIN_LIQUIDITY_USD='10000'
export MAX_ENTRY_PRICE_IMPACT_PCT='5'
export CHECK_MIN_SEC='1'
export CHECK_MAX_SEC='1'
export FILTER_CONCURRENCY='2'
export VAULT_START_RUB='5000'
export VAULT_STEP_RUB='2500'
export VAULT_SHARE='0.5'
export PUMP_SOURCE='helius-logs'
export SOURCES='raydium-v4,raydium-cpmm,meteora-dlmm,meteora-damm,meteora-dbc'
export HONEYPOT_CHECK='off'
export ONLY_SOL_PAIRS='on'
export WALLET_PATH="$WORK/wallet.json"
export TRADE_LOG="$WORK/trades.log"
export DB_PATH="$WORK/sniper.db"

# Проверяем итоговые настройки и доказываем, что PumpPortal не включится.
python3 - <<'PY' || exit 8
from config import load_settings
from detector import PUMP_PROGRAM_ID, select_programs

settings = load_settings()
programs = select_programs(settings.sources)
assert settings.mode == 'portfolio'
assert settings.max_hold_sec == 120
assert settings.max_positions == 1
assert settings.min_liquidity_usd == 10_000
assert settings.max_entry_price_impact_pct == 5
assert settings.pump_source == 'helius-logs'
assert PUMP_PROGRAM_ID not in programs
assert len(programs) == 5
print('PRE-FLIGHT OK: paper-only profile, five DEX sources, no PumpPortal, MAX_HOLD_SEC=120')
PY

mkdir -p "$WORK"
rm -rf "$LIVE"
mkdir -p "$LIVE"
cat > "$LIVE/manifest.txt" <<EOF
run_id=$RUN_ID
profile=quality-rocket2-realistic
mode=portfolio
status=starting
work_dir=$WORK
live_dir=$LIVE
archive_dir=$ARCHIVE
started_local=$(date -Is)
started_utc=$(date -u -Is)
execution=paper-only; Jupiter GET ExactIn quotes only; no transactions sent
strategy_source=clean historical 2-rocket2 exit thresholds; old model was not quote-realistic
max_hold_sec=$MAX_HOLD_SEC
take_profit_pct=$TAKE_PROFIT_PCT
trail_pct=$TRAIL_PCT
stagnation_sec=$STAGNATION_SEC
stagnation_range_pct=$STAGNATION_RANGE_PCT
be_offset_pct=$BE_OFFSET_PCT
stop_loss_pct=$STOP_LOSS_PCT
entry_fee_sol=$ENTRY_FEE_SOL
exit_fee_sol=$EXIT_FEE_SOL
max_positions=$MAX_POSITIONS
max_trade_rub=$MAX_TRADE_RUB
min_liquidity_usd=$MIN_LIQUIDITY_USD
max_entry_price_impact_pct=$MAX_ENTRY_PRICE_IMPACT_PCT
check_min_sec=$CHECK_MIN_SEC
check_max_sec=$CHECK_MAX_SEC
filter_concurrency=$FILTER_CONCURRENCY
sources=$SOURCES
pump_source=$PUMP_SOURCE
honeypot_fixed_size_check=$HONEYPOT_CHECK
entry_route_check=exact-size-buy-and-exact-size-sell-precheck
liquidity_filter=actual DexScreener liquidity.usd / GeckoTerminal reserve_in_usd
EOF
cp -f "$LIVE/manifest.txt" "$WORK/manifest.txt"
printf 'RUN_ID=%s\nWORK_DIR=%s\nLIVE_DIR=%s\nARCHIVE_DIR=%s\n' \
    "$RUN_ID" "$WORK" "$LIVE" "$ARCHIVE" > "$CURRENT"

start_epoch="$(date +%s)"
printf '%s\n' "$start_epoch" > "$WORK/start_epoch"
printf 'START local=%s utc=%s run_id=%s\n' "$(date -Is)" "$(date -u -Is)" "$RUN_ID"
printf 'PROFILE quality-rocket2-realistic: TP=40%% TRAIL=20%% STAGNATION=240s/3%% BE=7%% SL=12%% MAX_HOLD_SEC=120; one slot; liquidity>=$10,000; impact<=5%%; DEX-only\n'
printf 'PAPER ONLY: no real transactions; one-hour window starts now.\n'

cd "$WORK"
timeout --signal=INT --kill-after=20s 3600 \
    python3 -u "$PROJECT/main.py" > "$WORK/console.log" 2>&1 &
bot_pid=$!
printf '%s\n' "$bot_pid" > "$WORK/bot.pid"
printf 'bot_pid=%s\n' "$bot_pid" >> "$LIVE/manifest.txt"
printf 'bot_pid=%s\n' "$bot_pid" >> "$WORK/manifest.txt"

wait "$bot_pid"
rc=$?
finished_epoch="$(date +%s)"
elapsed=$((finished_epoch - start_epoch))
for file in console.log sniper.db wallet.json trades.log; do
    if [ -f "$WORK/$file" ]; then
        cp -f "$WORK/$file" "$LIVE/$file.tmp" 2>/dev/null \
            && mv -f "$LIVE/$file.tmp" "$LIVE/$file" 2>/dev/null || true
    fi
done
printf 'status=finished\nexit_code=%s\nelapsed_sec=%s\nfinished_local=%s\nfinished_utc=%s\n' \
    "$rc" "$elapsed" "$(date -Is)" "$(date -u -Is)" >> "$LIVE/manifest.txt"
cp -f "$LIVE/manifest.txt" "$WORK/manifest.txt"
touch "$WORK/runner_finished"
printf 'FINISH exit_code=%s elapsed_sec=%s local=%s utc=%s\n' \
    "$rc" "$elapsed" "$(date -Is)" "$(date -u -Is)"

# timeout returns 124 after the intended one-hour window.
if [ "$rc" -ne 0 ] && [ "$rc" -ne 124 ]; then
    exit "$rc"
fi
exit 0

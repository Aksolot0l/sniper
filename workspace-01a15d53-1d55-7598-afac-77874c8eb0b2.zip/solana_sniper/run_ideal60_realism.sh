#!/usr/bin/env bash
set -uo pipefail

PROJECT='/home/user/solana_sniper'
WORK='/tmp/ideal60-realistic-run'
LIVE="$PROJECT/runs/ideal60-realism-live"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)"
ARCHIVE="$PROJECT/runs/realism-ideal60-$RUN_ID"

cd "$PROJECT"
mkdir -p "$PROJECT/runs"

if pgrep -af '[p]ython3 -u /home/user/solana_sniper/main.py' >/dev/null; then
    echo 'ERROR: найден другой main.py; второй paper-прогон не запускаю.'
    exit 2
fi
if pgrep -af '[b]ash /home/user/run12h.sh|[b]ash /home/user/solana_sniper/run12h.sh' >/dev/null; then
    echo 'ERROR: найден активный matrix-runner; второй runner не запускаю.'
    exit 3
fi
if pgrep -af '[b]ash /home/user/sync.sh' >/dev/null; then
    echo 'ERROR: найден старый sync.sh; сначала остановить его, чтобы не было общей записи.'
    exit 3
fi

mkdir -p "$WORK"
exec 9>"$WORK.lock"
if ! flock -n 9; then
    echo 'ERROR: другой ideal60 paper-прогон уже использует этот каталог.'
    exit 4
fi
if ! python3 -c 'import websockets, aiohttp, aiosqlite' >/dev/null 2>&1; then
    echo 'Устанавливаю зависимости из requirements.txt до запуска paper-прогона.'
    python3 -m pip install --user -r "$PROJECT/requirements.txt" || exit 5
fi
rm -f "$WORK"/*
rm -rf "$LIVE"
mkdir -p "$LIVE"
printf 'run_id=%s\nprofile=ideal60\nmode=portfolio\n' "$RUN_ID" > "$LIVE/manifest.txt"

export MODE='portfolio'
export DEPOSIT_RUB='1500'
export MAX_HOLD_SEC='120'
export TAKE_PROFIT_PCT='35'
export TRAIL_PCT='18'
export STAGNATION_SEC='60'
export STAGNATION_RANGE_PCT='2'
export BE_OFFSET_PCT='6'
export STOP_LOSS_PCT='10'
export ENTRY_FEE_SOL='0.0005'
export EXIT_FEE_SOL='0.0001'
export PROTOCOL_FEE_PCT='1.25'
export USD_RUB_RATE='90'
export MAX_TRADE_RUB='1500'
export MAX_POSITIONS='2'
export MIN_LIQUIDITY_USD='3000'
export CHECK_MIN_SEC='0.5'
export CHECK_MAX_SEC='0.5'
export FILTER_CONCURRENCY='6'
export VAULT_START_RUB='5000'
export VAULT_STEP_RUB='2500'
export VAULT_SHARE='0.5'
export PUMP_SOURCE='pumpportal'
export SOURCES='all'
export HONEYPOT_CHECK='on'
export ONLY_SOL_PAIRS='on'
export WALLET_PATH="$WORK/wallet.json"
export TRADE_LOG="$WORK/trades.log"
export DB_PATH="$WORK/sniper.db"
{
    printf 'deposit_rub=%s\nmax_hold_sec=%s\ntake_profit_pct=%s\n' \
        "$DEPOSIT_RUB" "$MAX_HOLD_SEC" "$TAKE_PROFIT_PCT"
    printf 'trail_pct=%s\nstagnation_sec=%s\nstagnation_range_pct=%s\n' \
        "$TRAIL_PCT" "$STAGNATION_SEC" "$STAGNATION_RANGE_PCT"
    printf 'be_offset_pct=%s\nstop_loss_pct=%s\nentry_fee_sol=%s\n' \
        "$BE_OFFSET_PCT" "$STOP_LOSS_PCT" "$ENTRY_FEE_SOL"
    printf 'exit_fee_sol=%s\nmax_positions=%s\nmin_liquidity_usd=%s\n' \
        "$EXIT_FEE_SOL" "$MAX_POSITIONS" "$MIN_LIQUIDITY_USD"
    printf 'check_min_sec=%s\ncheck_max_sec=%s\nsources=%s\n' \
        "$CHECK_MIN_SEC" "$CHECK_MAX_SEC" "$SOURCES"
} >> "$LIVE/manifest.txt"

printf 'START local=%s utc=%s\n' "$(date -Is)" "$(date -u -Is)"
printf 'PROFILE ideal60: TP=35%% TRAIL=18%% STAGNATION=60s/2%% BE=6%% SL=10%% MAX_HOLD_SEC=120 MAX_POSITIONS=2 ENTRY_FEE_SOL=0.0005 MIN_LIQUIDITY_USD=3000 CHECK=0.5s\n'

cd "$WORK"
timeout --signal=INT --kill-after=20s 3600 \
    python3 -u "$PROJECT/main.py" > "$WORK/console.log" 2>&1 &
bot_pid=$!
start_epoch="$(date +%s)"
last_heartbeat=0

while kill -0 "$bot_pid" 2>/dev/null; do
    for file in console.log sniper.db wallet.json trades.log; do
        if [ -f "$WORK/$file" ]; then
            cp -f "$WORK/$file" "$LIVE/$file.tmp" 2>/dev/null \
                && mv -f "$LIVE/$file.tmp" "$LIVE/$file" 2>/dev/null || true
        fi
    done

    now="$(date +%s)"
    elapsed=$((now - start_epoch))
    if [ $((elapsed - last_heartbeat)) -ge 60 ]; then
        last_heartbeat="$elapsed"
        python3 - "$WORK/wallet.json" "$elapsed" <<'PY'
import json
import sys
from pathlib import Path
path = Path(sys.argv[1])
elapsed = int(sys.argv[2])
try:
    data = json.loads(path.read_text(encoding='utf-8'))
    closed_count = len(data.get('trades', []))
    open_count = len(data.get('open_positions', []))
    balance = float(data.get('balance_rub', 0.0))
    vault = float(data.get('vault_rub', 0.0))
    print(
        f'HEARTBEAT elapsed={elapsed}s closed={closed_count} open={open_count} '
        f'balance={balance:.2f} vault={vault:.2f}',
        flush=True,
    )
except Exception as exc:
    print(f'HEARTBEAT elapsed={elapsed}s wallet_pending={type(exc).__name__}', flush=True)
PY
    fi
    sleep 8
done

wait "$bot_pid"
rc=$?
for file in console.log sniper.db wallet.json trades.log; do
    if [ -f "$WORK/$file" ]; then
        cp -f "$WORK/$file" "$LIVE/$file.tmp" 2>/dev/null \
            && mv -f "$LIVE/$file.tmp" "$LIVE/$file" 2>/dev/null || true
    fi
done
printf 'exit_code=%s\nfinished_local=%s\nfinished_utc=%s\n' \
    "$rc" "$(date -Is)" "$(date -u -Is)" >> "$LIVE/manifest.txt"

mkdir -p "$ARCHIVE"
cp -f "$LIVE"/{manifest.txt,console.log,sniper.db,wallet.json,trades.log} "$ARCHIVE"/ 2>/dev/null || true
cp -f "$LIVE/manifest.txt" "$ARCHIVE/manifest.txt" 2>/dev/null || true
printf 'FINISH exit_code=%s local=%s utc=%s archive=%s\n' \
    "$rc" "$(date -Is)" "$(date -u -Is)" "$ARCHIVE"

if [ "$rc" -ne 0 ] && [ "$rc" -ne 124 ]; then
    exit "$rc"
fi
exit 0

#!/usr/bin/env bash
set -uo pipefail

PROJECT='/home/user/solana_sniper'
CURRENT="$PROJECT/runs/config6-current.env"
if [ ! -f "$CURRENT" ]; then
    echo 'ERROR: config6-current.env не найден; monitor не запущен.'
    exit 2
fi
# shellcheck disable=SC1090
source "$CURRENT"

copy_live_files() {
    for file in console.log wallet.json trades.log; do
        if [ -f "$WORK_DIR/$file" ]; then
            cp -f "$WORK_DIR/$file" "$LIVE_DIR/$file.tmp" 2>/dev/null \
                && mv -f "$LIVE_DIR/$file.tmp" "$LIVE_DIR/$file" 2>/dev/null || true
        fi
    done
}

report_window() {
    local window_start="$1"
    local window_end="$2"
    local partial="$3"
    python3 - "$WORK_DIR/console.log" "$WORK_DIR/wallet.json" \
        "$WORK_DIR/start_epoch" "$window_start" "$window_end" "$partial" <<'PY'
import json
import re
import sys
from datetime import datetime, time, timedelta, timezone
from pathlib import Path

log_path = Path(sys.argv[1])
wallet_path = Path(sys.argv[2])
start_path = Path(sys.argv[3])
window_start = int(sys.argv[4])
window_end = int(sys.argv[5])
partial = sys.argv[6] == 'true'
start_epoch = int(start_path.read_text().strip())
start_dt = datetime.fromtimestamp(start_epoch, timezone.utc)
ansi = re.compile(r'\x1b\[[0-9;]*m')
fill_pnl = re.compile(
    r'Paper-fill по quote:.*?PnL части ([+-]?\d+(?:\.\d+)?) ₽'
)
patterns = {
    'detected': '👁️ Новая монета:',
    'no_buy_quote': 'Jupiter не подтвердил маршрут покупки для фактического размера',
    'no_sell_precheck': 'нет подтверждённого Jupiter-маршрута продажи для точного количества токенов',
    'filter_blocks': 'фильтры заблокировали:',
    'buy_impact_blocks': 'impact покупки',
    'sell_impact_blocks': 'impact точной продажи',
    'slot_busy': 'слота заняты',
    'entries': 'ФЕЙК ПОКУПКА',
    'quote_fills': 'Paper-fill по quote',
    'full_closes': 'ФЕЙК ПРОДАЖА!',
    'sell_quote_misses': 'Jupiter не подтвердил свежий маршрут',
    'sell_trigger_unconfirmed': 'не подтверждён исполнимой quote',
}
counts = {key: 0 for key in patterns}
window_pnl = 0.0
http_429 = 0
try:
    lines = log_path.read_text(encoding='utf-8', errors='replace').splitlines()
except Exception:
    lines = []
for line in lines:
    plain = ansi.sub('', line)
    match = re.match(r'^\[(\d{2}:\d{2}:\d{2})\]', plain)
    if not match:
        continue
    clock = time.fromisoformat(match.group(1))
    event_dt = datetime.combine(start_dt.date(), clock, timezone.utc)
    if event_dt < start_dt - timedelta(hours=12):
        event_dt += timedelta(days=1)
    event_elapsed = (event_dt - start_dt).total_seconds()
    if not window_start <= event_elapsed < window_end:
        continue
    for key, marker in patterns.items():
        if marker in plain:
            counts[key] += 1
    pnl_match = fill_pnl.search(plain)
    if pnl_match:
        window_pnl += float(pnl_match.group(1))
    if re.search(
        r'\b(?:HTTP(?:/[0-9.]+)?\s+429|status(?:\s+|[:=])429)\b',
        plain,
        re.I,
    ):
        http_429 += 1
try:
    wallet = json.loads(wallet_path.read_text(encoding='utf-8'))
except Exception:
    wallet = {}
trades = wallet.get('trades', [])
positions = wallet.get('open_positions', [])
try:
    total_pnl = float(wallet.get('total_pnl', 0.0))
    balance = float(wallet.get('balance_rub', 0.0))
    fees = float(wallet.get('fees_paid_rub', 0.0))
except (TypeError, ValueError):
    total_pnl = balance = fees = 0.0
wins = sum(1 for t in trades if float(t.get('pnl_rub', 0.0)) > 0)
pending = sum(1 for pos in positions if pos.get('exit_pending'))
start_min = window_start // 60
if window_end % 600 == 0:
    end_label = f'{window_end // 60:02d}min'
else:
    end_label = f'{window_end // 60:02d}m{window_end % 60:02d}s'
label = f'{start_min:02d}min-{end_label}'
partial_label = ' partial=true' if partial else ''
print(
    f'📊 CYCLE_REPORT window={label}{partial_label} '
    f"detected={counts['detected']} entries={counts['entries']} "
    f"no_buy_quote={counts['no_buy_quote']} "
    f"no_sell_precheck={counts['no_sell_precheck']} "
    f"filter_blocks={counts['filter_blocks']} "
    f"buy_impact_blocks={counts['buy_impact_blocks']} "
    f"sell_impact_blocks={counts['sell_impact_blocks']} "
    f"slot_busy={counts['slot_busy']} quote_fills={counts['quote_fills']} "
    f"full_closes={counts['full_closes']} "
    f"sell_quote_misses={counts['sell_quote_misses']} "
    f"sell_trigger_unconfirmed={counts['sell_trigger_unconfirmed']} "
    f'realized_window_pnl={window_pnl:+.2f} '
    f'cumulative_realized_pnl={total_pnl:+.2f} '
    f'closed_records={len(trades)} wins={wins} balance={balance:.2f} '
    f'fees={fees:.2f} open={len(positions)} pending={pending} '
    f'http_429={http_429}',
    flush=True,
)
PY
}

start_epoch=0
if [ -f "$WORK_DIR/start_epoch" ]; then
    start_epoch="$(cat "$WORK_DIR/start_epoch" 2>/dev/null || echo 0)"
fi
last_heartbeat=0
next_cycle=600
pid_missing_since=0
printf 'SYNC START run_id=%s work=%s live=%s\n' "$RUN_ID" "$WORK_DIR" "$LIVE_DIR"

while :; do
    copy_live_files
    if [ "$start_epoch" -le 0 ] && [ -f "$WORK_DIR/start_epoch" ]; then
        start_epoch="$(cat "$WORK_DIR/start_epoch" 2>/dev/null || echo 0)"
    fi
    now="$(date +%s)"
    if [ "$start_epoch" -gt 0 ]; then
        elapsed=$((now - start_epoch))
    else
        elapsed=0
    fi

    while [ "$elapsed" -ge "$next_cycle" ]; do
        report_window "$((next_cycle - 600))" "$next_cycle" false
        next_cycle=$((next_cycle + 600))
    done

    if [ $((elapsed - last_heartbeat)) -ge 60 ]; then
        last_heartbeat="$elapsed"
        python3 - "$WORK_DIR/wallet.json" "$WORK_DIR/console.log" "$elapsed" <<'PY'
import json
import re
import sys
from pathlib import Path
wallet_path = Path(sys.argv[1])
log_path = Path(sys.argv[2])
elapsed = int(sys.argv[3])
try:
    data = json.loads(wallet_path.read_text(encoding='utf-8'))
    trades = data.get('trades', [])
    positions = data.get('open_positions', [])
    wins = sum(1 for trade in trades if float(trade.get('pnl_rub', 0.0)) > 0)
    state = (
        f'closed={len(trades)} wins={wins} '
        f'realized_pnl={float(data.get("total_pnl", 0.0)):+.2f} '
        f'balance={float(data.get("balance_rub", 0.0)):.2f} '
        f'fees={float(data.get("fees_paid_rub", 0.0)):.2f} '
        f'open={len(positions)} '
        f'pending={sum(1 for pos in positions if pos.get("exit_pending"))}'
    )
except Exception as exc:
    state = f'wallet_pending={type(exc).__name__}'
try:
    text = log_path.read_text(encoding='utf-8', errors='replace')
    http_429 = sum(
        1 for line in text.splitlines()
        if re.search(
            r'\b(?:HTTP(?:/[0-9.]+)?\s+429|status(?:\s+|[:=])429)\b',
            line,
            re.I,
        )
    )
except Exception:
    http_429 = 0
print(f'HEARTBEAT elapsed={elapsed}s {state} http_429={http_429}', flush=True)
PY
    fi

    if [ -f "$WORK_DIR/runner_finished" ]; then
        if [ "$start_epoch" -gt 0 ] && [ "$elapsed" -gt $((next_cycle - 600)) ]; then
            report_window "$((next_cycle - 600))" "$elapsed" true
        fi
        break
    fi

    if [ -f "$WORK_DIR/bot.pid" ]; then
        bot_pid="$(cat "$WORK_DIR/bot.pid" 2>/dev/null || echo 0)"
        if [ "$bot_pid" -gt 0 ] && ! kill -0 "$bot_pid" 2>/dev/null; then
            if [ "$pid_missing_since" -eq 0 ]; then
                pid_missing_since="$now"
            elif [ $((now - pid_missing_since)) -ge 30 ]; then
                echo "SYNC: bot pid $bot_pid завершился без runner_finished; делаю финальный снимок."
                if [ "$start_epoch" -gt 0 ] && [ "$elapsed" -gt $((next_cycle - 600)) ]; then
                    report_window "$((next_cycle - 600))" "$elapsed" true
                fi
                break
            fi
        else
            pid_missing_since=0
        fi
    fi
    sleep 8
done

copy_live_files
for file in manifest.txt console.log wallet.json trades.log sniper.db sniper.db-wal sniper.db-shm; do
    if [ -f "$WORK_DIR/$file" ]; then
        cp -f "$WORK_DIR/$file" "$LIVE_DIR/$file.tmp" 2>/dev/null \
            && mv -f "$LIVE_DIR/$file.tmp" "$LIVE_DIR/$file" 2>/dev/null || true
    fi
done
if [ ! -f "$WORK_DIR/runner_finished" ]; then
    printf '\nstatus=monitor_recovered_after_runner_exit\nfinished_utc=%s\n' \
        "$(date -u -Is)" >> "$LIVE_DIR/manifest.txt"
fi

mkdir -p "$ARCHIVE_DIR"
for file in manifest.txt console.log wallet.json trades.log sniper.db sniper.db-wal sniper.db-shm; do
    if [ -f "$LIVE_DIR/$file" ]; then
        cp -f "$LIVE_DIR/$file" "$ARCHIVE_DIR/$file"
    fi
done
printf 'SYNC FINISH run_id=%s archive=%s utc=%s\n' \
    "$RUN_ID" "$ARCHIVE_DIR" "$(date -u -Is)"

#!/usr/bin/env bash
set -uo pipefail

PROJECT='/home/user/solana_sniper'
PYTHON="$PROJECT/.venv/bin/python3"
if [ ! -x "$PYTHON" ]; then PYTHON="$(command -v python3)"; fi
RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
WORK="/tmp/config6-ideal60-$RUN_ID"
LIVE="$PROJECT/runs/config6-ideal60-live"
ARCHIVE="$PROJECT/runs/config6-ideal60-$RUN_ID"
CURRENT="$PROJECT/runs/config6-current.env"

cd "$PROJECT"
mkdir -p "$PROJECT/runs"

if pgrep -af '[p]ython3 -u /home/user/solana_sniper/main.py' >/dev/null; then
    echo 'ERROR: найден другой main.py; второй paper-прогон не запускаю.'
    exit 2
fi
if pgrep -af '[b]ash /home/user/solana_sniper/run12h.sh|[b]ash /home/user/solana_sniper/run_config4_hour.sh|[b]ash /home/user/solana_sniper/run_config5_frequency_hour.sh' >/dev/null; then
    echo 'ERROR: найден активный runner; новый прогон не запускаю.'
    exit 3
fi

exec 9>"$PROJECT/runs/config6-ideal60.lock"
if ! flock -n 9; then
    echo 'ERROR: config6 runner уже использует lock.'
    exit 4
fi
if ! "$PYTHON" -c 'import websockets, aiohttp, aiosqlite' >/dev/null 2>&1; then
    echo 'ERROR: зависимости отсутствуют в выбранном Python; прогон не стартовал.'
    exit 5
fi
"$PYTHON" -m py_compile config.py filters.py trader.py wallet.py main.py detector.py price.py || exit 6
"$PYTHON" -m unittest discover -s tests -v || exit 7

# Config6: ранний ideal60 exit profile + текущие quote-confirmed safety gates.
export MODE='portfolio'
export DEPOSIT_RUB='1500'
export MAX_HOLD_SEC='120'
export TAKE_PROFIT_PCT='35'
export TRAIL_PCT='18'
export STAGNATION_SEC='60'
export STAGNATION_RANGE_PCT='2'
export BE_OFFSET_PCT='6'
export STOP_LOSS_PCT='10'
export ENTRY_FEE_SOL='0.0005'
export EXIT_FEE_SOL='0.0001'
export PROTOCOL_FEE_PCT='1.25'
export USD_RUB_RATE='90'
export MAX_TRADE_RUB='500'
export MAX_POSITIONS='2'
export MIN_LIQUIDITY_USD='3000'
export MAX_ENTRY_PRICE_IMPACT_PCT='5'
export ENTRY_QUOTE_RETRIES='3'
export ENTRY_QUOTE_RETRY_DELAY_SEC='1'
export INDEXER_RETRIES='1'
export INDEXER_RETRY_DELAY_SEC='1'
export CHECK_MIN_SEC='1'
export CHECK_MAX_SEC='1'
export FILTER_CONCURRENCY='2'
export VAULT_START_RUB='5000'
export VAULT_STEP_RUB='2500'
export VAULT_SHARE='0.5'
export PUMP_SOURCE='pumpportal'
export SOURCES='all'
export HONEYPOT_CHECK='off'
export ONLY_SOL_PAIRS='on'
export WALLET_PATH="$WORK/wallet.json"
export TRADE_LOG="$WORK/trades.log"
export DB_PATH="$WORK/sniper.db"

"$PYTHON" - <<'PY' || exit 8
from config import load_settings
from detector import PUMP_PROGRAM_ID, select_programs
s = load_settings()
programs = select_programs(s.sources)
assert s.mode == 'portfolio' and s.deposit_rub == 1500
assert s.take_profit_pct == 35 and s.stop_loss_pct == 10
assert s.max_hold_sec == 120 and s.stagnation_sec == 60
assert s.stagnation_range_pct == 2 and s.be_offset_pct == 6 and s.trail_pct == 18
assert s.max_positions == 2 and s.max_trade_rub == 500
assert s.min_liquidity_usd == 3000 and s.max_entry_price_impact_pct == 5
assert s.entry_quote_retries == 3 and s.entry_quote_retry_delay_sec == 1
assert s.indexer_retries == 1 and s.indexer_retry_delay_sec == 1
assert s.pump_source == 'pumpportal' and s.only_sol_pairs and not s.honeypot_check
assert s.check_min_sec == 1 and s.check_max_sec == 1
assert PUMP_PROGRAM_ID in programs and len(programs) == 6
print('PRE-FLIGHT OK: ideal60 exits; Pump.fun + all six sources; 2×500 ₽; exact quote gates; impact<=5%; retries bounded')
PY

mkdir -p "$WORK"
rm -rf "$LIVE"
mkdir -p "$LIVE"
cat > "$LIVE/manifest.txt" <<EOF
run_id=$RUN_ID
profile=config6-ideal60-quote-confirmed
mode=portfolio
status=starting
work_dir=$WORK
live_dir=$LIVE
archive_dir=$ARCHIVE
started_utc=$(date -u -Is)
planned_sec=3600
execution=paper-only; Jupiter GET ExactIn quotes only; no transactions sent
basis=pre-config ideal60 exit parameters; modern quote-confirmed fills retained
position_cap_rub=$MAX_TRADE_RUB
max_positions=$MAX_POSITIONS
max_total_open_notional_rub=1000
entry_quote_retries=$ENTRY_QUOTE_RETRIES
entry_quote_retry_delay_sec=$ENTRY_QUOTE_RETRY_DELAY_SEC
indexer_retries=$INDEXER_RETRIES
indexer_retry_delay_sec=$INDEXER_RETRY_DELAY_SEC
max_hold_sec=$MAX_HOLD_SEC
take_profit_pct=$TAKE_PROFIT_PCT
trail_pct=$TRAIL_PCT
stagnation_sec=$STAGNATION_SEC
stagnation_range_pct=$STAGNATION_RANGE_PCT
be_offset_pct=$BE_OFFSET_PCT
stop_loss_pct=$STOP_LOSS_PCT
entry_fee_sol=$ENTRY_FEE_SOL
exit_fee_sol=$EXIT_FEE_SOL
min_liquidity_usd=$MIN_LIQUIDITY_USD
max_entry_price_impact_pct=$MAX_ENTRY_PRICE_IMPACT_PCT
slippage_bps=100
check_min_sec=$CHECK_MIN_SEC
check_max_sec=$CHECK_MAX_SEC
filter_concurrency=$FILTER_CONCURRENCY
sources=$SOURCES
pump_source=$PUMP_SOURCE
only_sol_pairs=$ONLY_SOL_PAIRS
honeypot_fixed_size_check=$HONEYPOT_CHECK
entry_route_check=exact-size-buy-and-exact-size-sell-precheck; no fill without fresh sell quote
liquidity_rule=threshold=$MIN_LIQUIDITY_USD; indexer retry only if both sources return no data
EOF
cp -f "$LIVE/manifest.txt" "$WORK/manifest.txt"
printf 'RUN_ID=%s\nWORK_DIR=%s\nLIVE_DIR=%s\nARCHIVE_DIR=%s\n' \
    "$RUN_ID" "$WORK" "$LIVE" "$ARCHIVE" > "$CURRENT"

start_epoch="$(date +%s)"
printf '%s\n' "$start_epoch" > "$WORK/start_epoch"
printf 'START utc=%s run_id=%s\n' "$(date -u -Is)" "$RUN_ID"
printf 'PROFILE #6 (early ideal60 basis): TP35/SL10/BE6/trailing18; stagnation60s/2%%; 2 slots × cap500 ₽.\n'
printf 'Pump.fun ENABLED: SOURCES=all, PUMP_SOURCE=pumpportal. Liquidity >= $3,000, exact-size quotes, impact<=5%%, slippage100bps.\n'
printf 'PAPER ONLY: fresh 1,500 ₽ wallet; no real transactions; one-hour observation starts now.\n'

cd "$WORK"
timeout --signal=INT --kill-after=20s 3600 \
    "$PYTHON" -u "$PROJECT/main.py" > "$WORK/console.log" 2>&1 &
bot_pid=$!
printf '%s\n' "$bot_pid" > "$WORK/bot.pid"
printf 'bot_pid=%s\n' "$bot_pid" >> "$LIVE/manifest.txt"
printf 'bot_pid=%s\n' "$bot_pid" >> "$WORK/manifest.txt"

wait "$bot_pid"
rc=$?
finished_epoch="$(date +%s)"
elapsed=$((finished_epoch - start_epoch))
for file in console.log sniper.db sniper.db-wal sniper.db-shm wallet.json trades.log; do
    if [ -f "$WORK/$file" ]; then
        cp -f "$WORK/$file" "$LIVE/$file.tmp" 2>/dev/null \
            && mv -f "$LIVE/$file.tmp" "$LIVE/$file" 2>/dev/null || true
    fi
done
printf 'status=finished\nexit_code=%s\nelapsed_sec=%s\nfinished_utc=%s\n' \
    "$rc" "$elapsed" "$(date -u -Is)" >> "$LIVE/manifest.txt"
cp -f "$LIVE/manifest.txt" "$WORK/manifest.txt"
touch "$WORK/runner_finished"
printf 'FINISH exit_code=%s elapsed_sec=%s utc=%s\n' \
    "$rc" "$elapsed" "$(date -u -Is)"

if [ "$rc" -ne 0 ] && [ "$rc" -ne 124 ]; then
    exit "$rc"
fi
exit 0

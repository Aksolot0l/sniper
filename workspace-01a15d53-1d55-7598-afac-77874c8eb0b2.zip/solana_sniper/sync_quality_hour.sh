#!/usr/bin/env bash
set -uo pipefail

PROJECT='/home/user/solana_sniper'
CURRENT="$PROJECT/runs/quality-rocket2-current.env"

if [ ! -f "$CURRENT" ]; then
    echo 'ERROR: current.env не найден; синхронизация не запущена.'
    exit 2
fi
# CURRENT создаётся runner-ом и содержит только пути этого запуска.
# shellcheck disable=SC1090
source "$CURRENT"

copy_live_files() {
    for file in console.log wallet.json trades.log; do
        if [ -f "$WORK_DIR/$file" ]; then
            cp -f "$WORK_DIR/$file" "$LIVE_DIR/$file.tmp" 2>/dev/null \
                && mv -f "$LIVE_DIR/$file.tmp" "$LIVE_DIR/$file" 2>/dev/null || true
        fi
    done
}

start_epoch=0
if [ -f "$WORK_DIR/start_epoch" ]; then
    start_epoch="$(cat "$WORK_DIR/start_epoch" 2>/dev/null || echo 0)"
fi
last_heartbeat=0
pid_missing_since=0
printf 'SYNC START run_id=%s work=%s live=%s\n' "$RUN_ID" "$WORK_DIR" "$LIVE_DIR"

while :; do
    copy_live_files
    if [ "$start_epoch" -le 0 ] && [ -f "$WORK_DIR/start_epoch" ]; then
        start_epoch="$(cat "$WORK_DIR/start_epoch" 2>/dev/null || echo 0)"
    fi
    now="$(date +%s)"
    if [ "$start_epoch" -gt 0 ]; then
        elapsed=$((now - start_epoch))
    else
        elapsed=0
    fi

    # Heartbeat для оператора: статусы из виртуального кошелька и логов.
    if [ $((elapsed - last_heartbeat)) -ge 60 ]; then
        last_heartbeat="$elapsed"
        python3 - "$WORK_DIR/wallet.json" "$WORK_DIR/console.log" "$elapsed" <<'PY'
import json
import re
import sys
from pathlib import Path

wallet_path = Path(sys.argv[1])
log_path = Path(sys.argv[2])
elapsed = int(sys.argv[3])
try:
    data = json.loads(wallet_path.read_text(encoding='utf-8'))
    trades = data.get('trades', [])
    wins = sum(1 for trade in trades if float(trade.get('pnl_rub', 0.0)) > 0)
    open_positions = data.get('open_positions', [])
    pending = sum(1 for pos in open_positions if pos.get('exit_pending'))
    balance = float(data.get('balance_rub', 0.0))
    pnl = float(data.get('total_pnl', 0.0))
    fees = float(data.get('fees_paid_rub', 0.0))
    closed_count = len(trades)
except Exception as exc:
    closed_count = wins = pending = 0
    balance = pnl = fees = 0.0
    open_positions = []
    wallet_state = f'wallet_pending={type(exc).__name__}'
else:
    wallet_state = (
        f'closed={closed_count} wins={wins} total_pnl={pnl:+.2f} '
        f'balance={balance:.2f} fees={fees:.2f} '
        f'open={len(open_positions)} pending={pending}'
    )
try:
    text = log_path.read_text(encoding='utf-8', errors='replace')
    http_429 = sum(
        1 for line in text.splitlines()
        if re.search(r'\b(?:HTTP(?:/[0-9.]+)?\s+429|status(?:\s+|[:=])429)\b', line, re.I)
    )
except Exception:
    http_429 = 0
print(f'HEARTBEAT elapsed={elapsed}s {wallet_state} http_429={http_429}', flush=True)
PY
    fi

    if [ -f "$WORK_DIR/runner_finished" ]; then
        break
    fi

    # Если оболочка runner прервалась, ждём завершения самого timeout-процесса.
    if [ -f "$WORK_DIR/bot.pid" ]; then
        bot_pid="$(cat "$WORK_DIR/bot.pid" 2>/dev/null || echo 0)"
        if [ "$bot_pid" -gt 0 ] && ! kill -0 "$bot_pid" 2>/dev/null; then
            if [ "$pid_missing_since" -eq 0 ]; then
                pid_missing_since="$now"
            elif [ $((now - pid_missing_since)) -ge 30 ]; then
                echo "SYNC: bot pid $bot_pid завершился без runner_finished; делаю финальный снимок."
                break
            fi
        else
            pid_missing_since=0
        fi
    fi
    sleep 8
done

copy_live_files
for file in manifest.txt console.log wallet.json trades.log sniper.db sniper.db-wal sniper.db-shm; do
    if [ -f "$WORK_DIR/$file" ]; then
        cp -f "$WORK_DIR/$file" "$LIVE_DIR/$file.tmp" 2>/dev/null \
            && mv -f "$LIVE_DIR/$file.tmp" "$LIVE_DIR/$file" 2>/dev/null || true
    fi
done

if [ ! -f "$WORK_DIR/runner_finished" ]; then
    printf '\nstatus=monitor_recovered_after_runner_exit\nfinished_local=%s\nfinished_utc=%s\n' \
        "$(date -Is)" "$(date -u -Is)" >> "$LIVE_DIR/manifest.txt"
fi

mkdir -p "$ARCHIVE_DIR"
for file in manifest.txt console.log wallet.json trades.log sniper.db sniper.db-wal sniper.db-shm; do
    if [ -f "$LIVE_DIR/$file" ]; then
        cp -f "$LIVE_DIR/$file" "$ARCHIVE_DIR/$file"
    fi
done
printf 'SYNC FINISH run_id=%s archive=%s local=%s utc=%s\n' \
    "$RUN_ID" "$ARCHIVE_DIR" "$(date -Is)" "$(date -u -Is)"

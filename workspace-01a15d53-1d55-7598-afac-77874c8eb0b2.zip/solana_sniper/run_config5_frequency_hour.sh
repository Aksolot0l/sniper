#!/usr/bin/env bash
set -uo pipefail

PROJECT='/home/user/solana_sniper'
PYTHON="$PROJECT/.venv/bin/python3"
if [ ! -x "$PYTHON" ]; then PYTHON="$(command -v python3)"; fi
RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
WORK="/tmp/config5-frequency-$RUN_ID"
LIVE="$PROJECT/runs/config5-frequency-live"
ARCHIVE="$PROJECT/runs/config5-frequency-$RUN_ID"
CURRENT="$PROJECT/runs/config5-current.env"

cd "$PROJECT"
mkdir -p "$PROJECT/runs"

if pgrep -af '[p]ython3 -u /home/user/solana_sniper/main.py' >/dev/null; then
    echo 'ERROR: найден другой main.py; второй paper-прогон не запускаю.'
    exit 2
fi
if pgrep -af '[b]ash /home/user/solana_sniper/run12h.sh|[b]ash /home/user/solana_sniper/run_config4_hour.sh' >/dev/null; then
    echo 'ERROR: найден активный runner; новый прогон не запускаю.'
    exit 3
fi

exec 9>"$PROJECT/runs/config5-frequency.lock"
if ! flock -n 9; then
    echo 'ERROR: config5 runner уже использует lock.'
    exit 4
fi

if ! "$PYTHON" -c 'import websockets, aiohttp, aiosqlite' >/dev/null 2>&1; then
    echo 'ERROR: зависимости не установлены; прогон не стартовал.'
    exit 5
fi
"$PYTHON" -m py_compile config.py filters.py trader.py wallet.py main.py detector.py price.py || exit 6
"$PYTHON" -m unittest discover -s tests -v || exit 7

# Profile №5: повышаем число допустимых попыток, а не ослабляем проверки.
export MODE='portfolio'
export DEPOSIT_RUB='1500'
export MAX_HOLD_SEC='120'
export TAKE_PROFIT_PCT='40'
export TRAIL_PCT='20'
export STAGNATION_SEC='60'
export STAGNATION_RANGE_PCT='3'
export BE_OFFSET_PCT='7'
export STOP_LOSS_PCT='12'
export ENTRY_FEE_SOL='0.0005'
export EXIT_FEE_SOL='0.0001'
export PROTOCOL_FEE_PCT='1.25'
export USD_RUB_RATE='90'
export MAX_TRADE_RUB='250'
export MAX_POSITIONS='2'
export MIN_LIQUIDITY_USD='5000'
export MAX_ENTRY_PRICE_IMPACT_PCT='5'
export ENTRY_QUOTE_RETRIES='3'
export ENTRY_QUOTE_RETRY_DELAY_SEC='1'
export INDEXER_RETRIES='1'
export INDEXER_RETRY_DELAY_SEC='1'
export CHECK_MIN_SEC='1'
export CHECK_MAX_SEC='1'
export FILTER_CONCURRENCY='2'
export VAULT_START_RUB='5000'
export VAULT_STEP_RUB='2500'
export VAULT_SHARE='0.5'
export PUMP_SOURCE='pumpportal'
export SOURCES='all'
export HONEYPOT_CHECK='off'
export ONLY_SOL_PAIRS='on'
export WALLET_PATH="$WORK/wallet.json"
export TRADE_LOG="$WORK/trades.log"
export DB_PATH="$WORK/sniper.db"

"$PYTHON" - <<'PY' || exit 8
from config import load_settings
from detector import PUMP_PROGRAM_ID, select_programs

settings = load_settings()
programs = select_programs(settings.sources)
assert settings.mode == 'portfolio'
assert settings.take_profit_pct == 40
assert settings.stop_loss_pct == 12
assert settings.max_hold_sec == 120
assert settings.stagnation_sec == 60
assert settings.stagnation_range_pct == 3
assert settings.be_offset_pct == 7
assert settings.trail_pct == 20
assert settings.max_positions == 2
assert settings.max_trade_rub == 250
assert settings.min_liquidity_usd == 5_000
assert settings.max_entry_price_impact_pct == 5
assert settings.entry_quote_retries == 3
assert settings.entry_quote_retry_delay_sec == 1
assert settings.indexer_retries == 1
assert settings.indexer_retry_delay_sec == 1
assert settings.only_sol_pairs and not settings.honeypot_check
assert PUMP_PROGRAM_ID in programs and len(programs) == 6
print('PRE-FLIGHT OK: 2 слота × cap 250 ₽; 3 quote-retries; 1 indexer retry; exact quote gates; impact<=5%')
PY

mkdir -p "$WORK"
rm -rf "$LIVE"
mkdir -p "$LIVE"
cat > "$LIVE/manifest.txt" <<EOF
run_id=$RUN_ID
profile=config5-frequency
mode=portfolio
status=starting
work_dir=$WORK
live_dir=$LIVE
archive_dir=$ARCHIVE
started_utc=$(date -u -Is)
planned_sec=3600
execution=paper-only; Jupiter GET ExactIn quotes only; no transactions sent
strategy=more eligible entries via bounded fresh-route/indexer retries and two slots
position_cap_rub=$MAX_TRADE_RUB
max_positions=$MAX_POSITIONS
max_total_open_notional_rub=500
entry_quote_retries=$ENTRY_QUOTE_RETRIES
entry_quote_retry_delay_sec=$ENTRY_QUOTE_RETRY_DELAY_SEC
indexer_retries=$INDEXER_RETRIES
indexer_retry_delay_sec=$INDEXER_RETRY_DELAY_SEC
max_hold_sec=$MAX_HOLD_SEC
take_profit_pct=$TAKE_PROFIT_PCT
trail_pct=$TRAIL_PCT
stagnation_sec=$STAGNATION_SEC
stagnation_range_pct=$STAGNATION_RANGE_PCT
be_offset_pct=$BE_OFFSET_PCT
stop_loss_pct=$STOP_LOSS_PCT
entry_fee_sol=$ENTRY_FEE_SOL
exit_fee_sol=$EXIT_FEE_SOL
min_liquidity_usd=$MIN_LIQUIDITY_USD
max_entry_price_impact_pct=$MAX_ENTRY_PRICE_IMPACT_PCT
slippage_bps=100
check_min_sec=$CHECK_MIN_SEC
check_max_sec=$CHECK_MAX_SEC
filter_concurrency=$FILTER_CONCURRENCY
sources=$SOURCES
pump_source=$PUMP_SOURCE
honeypot_fixed_size_check=$HONEYPOT_CHECK
entry_route_check=exact-size-buy-and-exact-size-sell-precheck; no fill without fresh sell quote
liquidity_rule=threshold remains $MIN_LIQUIDITY_USD; retry only if both indexers return no data
EOF
cp -f "$LIVE/manifest.txt" "$WORK/manifest.txt"
printf 'RUN_ID=%s\nWORK_DIR=%s\nLIVE_DIR=%s\nARCHIVE_DIR=%s\n' \
    "$RUN_ID" "$WORK" "$LIVE" "$ARCHIVE" > "$CURRENT"

start_epoch="$(date +%s)"
printf '%s\n' "$start_epoch" > "$WORK/start_epoch"
printf 'START utc=%s run_id=%s\n' "$(date -u -Is)" "$RUN_ID"
printf 'PROFILE #5: 2 slots × max 250 ₽; TP40/SL12; stagnation60; route retry 3× (1+2+3s); indexer retry1×.\n'
printf 'Safety gates unchanged: exact-size Jupiter buy/sell precheck; max impact 5%%; liquidity >= $5,000; 1%% slippage.\n'
printf 'PAPER ONLY: no real transactions; one-hour observation starts now.\n'

cd "$WORK"
timeout --signal=INT --kill-after=20s 3600 \
    "$PYTHON" -u "$PROJECT/main.py" > "$WORK/console.log" 2>&1 &
bot_pid=$!
printf '%s\n' "$bot_pid" > "$WORK/bot.pid"
printf 'bot_pid=%s\n' "$bot_pid" >> "$LIVE/manifest.txt"
printf 'bot_pid=%s\n' "$bot_pid" >> "$WORK/manifest.txt"

wait "$bot_pid"
rc=$?
finished_epoch="$(date +%s)"
elapsed=$((finished_epoch - start_epoch))
for file in console.log sniper.db sniper.db-wal sniper.db-shm wallet.json trades.log; do
    if [ -f "$WORK/$file" ]; then
        cp -f "$WORK/$file" "$LIVE/$file.tmp" 2>/dev/null \
            && mv -f "$LIVE/$file.tmp" "$LIVE/$file" 2>/dev/null || true
    fi
done
printf 'status=finished\nexit_code=%s\nelapsed_sec=%s\nfinished_utc=%s\n' \
    "$rc" "$elapsed" "$(date -u -Is)" >> "$LIVE/manifest.txt"
cp -f "$LIVE/manifest.txt" "$WORK/manifest.txt"
touch "$WORK/runner_finished"
printf 'FINISH exit_code=%s elapsed_sec=%s utc=%s\n' \
    "$rc" "$elapsed" "$(date -u -Is)"

if [ "$rc" -ne 0 ] && [ "$rc" -ne 124 ]; then
    exit "$rc"
fi
exit 0

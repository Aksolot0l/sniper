#!/bin/bash
# 15 прогонов по 15 минут, РАЗНЫЙ КОНФИГ на каждом (A/B-свод)
# Каждый прогон: чистый кошелёк 1500₽, артефакты в runs/<N>-<label>/
cd /home/user/solana_sniper
rm -rf runs
mkdir -p runs
i=0
run() {  # $1 = метка, остальные = VAR=VAL
    i=$((i+1))
    local label="$1"; shift
    echo "===== ПРОГОН $i/15 [$label] старт $(date +%H:%M:%S) ====="
    rm -f wallet.json trades.log sniper.db
    env "$@" MODE=portfolio timeout --signal=INT 905 \
        python3 -u main.py > "runs/console_$i.log" 2>&1
    mkdir -p "runs/$i-$label"
    [ -f wallet.json ] && mv wallet.json "runs/$i-$label/"
    [ -f trades.log ] && mv trades.log "runs/$i-$label/"
    [ -f sniper.db ] && mv sniper.db "runs/$i-$label/"
    echo "===== ПРОГОН $i/15 [$label] финиш $(date +%H:%M:%S) ====="
    sleep 5
}

# 1. Базовый (текущий конфиг)
run baseline
# 2-4. Окно застоя и размах
run stag300 STAGNATION_SEC=300
run stag120 STAGNATION_SEC=120
run stagrange5 STAGNATION_RANGE_PCT=5
# 5-6. Стоп-лосс
run sl15 STOP_LOSS_PCT=15
run sl20 STOP_LOSS_PCT=20
# 7-8. Тейк
run tp50 TAKE_PROFIT_PCT=50
run tp20 TAKE_PROFIT_PCT=20
# 9-10. Трейлинг
run trail25 TRAIL_PCT=25
run trail8 TRAIL_PCT=8
# 11. Безубыток выше
run be10 BE_OFFSET_PCT=10
# 12. Чувствительность к комиссии
run fee002 ENTRY_FEE_SOL=0.002
# 13. Концентрация: 2 слота
run slots2 MAX_POSITIONS=2
# 14. Медленный опрос (экономия RPC vs скорость выхода)
run check2s CHECK_MIN_SEC=2 CHECK_MAX_SEC=2
# 15. Пресет «держим ракету»
run rocket TAKE_PROFIT_PCT=50 STAGNATION_SEC=300 TRAIL_PCT=20 STOP_LOSS_PCT=15
echo "ВСЕ 15 ПРОГОНОВ ЗАВЕРШЕНЫ $(date +%H:%M:%S)"

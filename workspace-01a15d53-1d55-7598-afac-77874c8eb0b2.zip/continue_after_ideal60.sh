#!/usr/bin/env bash
set -euo pipefail

# Ждём завершения уже запущенного отрезка ideal60; второй бот не запускаем.
wait_pid="${1:?Нужен PID процесса текущего отрезка}"
while kill -0 "$wait_pid" 2>/dev/null; do
    sleep 2
done

cd /home/user/solana_sniper
mkdir -p runs/3-ideal60
for file in console.log sniper.db wallet.json trades.log; do
    if [ -f "/tmp/live_run/$file" ]; then
        cp -f "/tmp/live_run/$file" "runs/3-ideal60/$file"
    fi
done
if ! grep -q '^3 ideal60 ' runs/progress.txt 2>/dev/null; then
    echo "3 ideal60 $(date -u +%H:%M:%S) resumed" >> runs/progress.txt
fi

# run12h.sh сам пропустит готовые 1–3 и начнёт конфиг 4.
exec bash /home/user/run12h.sh 2>&1 | tee -a /home/user/solana_sniper/runs/runner.log

#!/bin/bash
# Независимая синхронизация /tmp/live_run -> runs/sync/.
# Живёт ОТДЕЛЬНО от run12h.sh: если тот умрёт, данные всё равно спасены.
while true; do
  mkdir -p /home/user/solana_sniper/runs/sync
  for f in console.log sniper.db wallet.json trades.log; do
    [ -f "/tmp/live_run/$f" ] && cp -f "/tmp/live_run/$f" "/home/user/solana_sniper/runs/sync/$f.tmp" 2>/dev/null \
      && mv -f "/home/user/solana_sniper/runs/sync/$f.tmp" "/home/user/solana_sniper/runs/sync/$f" 2>/dev/null
  done
  sleep 8
done

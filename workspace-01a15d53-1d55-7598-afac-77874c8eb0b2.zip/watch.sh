#!/bin/bash
# Дашборд живого прогона: /tmp/live_run -> компактная сводка в консоль.
L=/tmp/live_run/console.log
sed 's/\x1b\[[0-9;]*m//g' "$L" > /tmp/c.log 2>/dev/null

echo "════════ ДАШБОРД $(date +%H:%M:%S) ════════"
echo "── ПРОГРЕСС СЕССИИ ──"
echo "прогонов готово: $(ls -d /home/user/solana_sniper/runs/[1-9]-* /home/user/solana_sniper/runs/1[0-2]-* 2>/dev/null | wc -l)/12"
cat /home/user/solana_sniper/runs/progress.txt 2>/dev/null | tail -3
echo
echo "── СДЕЛКИ ТЕКУЩЕГО ПРОГОНА ──"
grep 'ФЕЙК ПОКУПКА' /tmp/c.log | sed 's/.*🟢 //; s/ (1\/3.*//' | tail -8
echo "…продажи:"
grep -A1 'ФЕЙК ПРОДАЖА' /tmp/c.log | grep 'причина' | sed 's/^.*причина: //' | tail -8
grep 'ФЕЙК ПРОДАЖА' /tmp/c.log | sed 's/.*🔴 //; s/ руб).*/ ₽)/' | tail -8
echo
echo "── КОШЕЛЁК ──"
python3 - <<'EOF'
import json
try:
    w = json.load(open('/tmp/live_run/wallet.json'))
    print(f"баланс: {w['balance_rub']:.2f} ₽ | сейф: {w['vault_rub']:.2f} ₽ | комиссии: {w.get('fees_paid_rub',0):.2f} ₽")
    for p in w.get('open_positions', []):
        print(f"  открытая: {p['mint'][:12]}… {p['invested_rub']:.2f} ₽")
except Exception as e:
    print('wallet:', e)
EOF
echo
echo "── ЖИВЫЕ ПОЗИЦИИ (последний тик) ──"
for m in $(grep -oE '[1-9A-HJ-NP-Za-km-z]{4,8}…[1-9A-HJ-NP-Za-km-z]{3,6}' /tmp/c.log | sort -u); do
  last=$(grep -F "$m" /tmp/c.log | grep 'от входа' | tail -1)
  [ -n "$last" ] && echo "$last"
done
echo
echo "── ЗДОРОВЬЕ ──"
echo "FileNotFoundError: $(grep -c FileNotFoundError /tmp/c.log) | Traceback: $(grep -c Traceback /tmp/c.log) | слоты заняты: $(grep -c 'слота заняты\|слотов заняты' /tmp/c.log)"
echo "Jupiter 429: $(grep -c 'HTTP 429' /tmp/c.log) | 400: $(grep -c 'HTTP 400' /tmp/c.log) | цена недоступна: $(grep -c 'цена недоступна' /tmp/c.log)"
echo "фантомы +1000%: $(grep -cE '→ \+[0-9]{3,}(\.[0-9])?%' /tmp/c.log)"
echo
echo "── СВОДКА ИЗ БД ──"
python3 - <<'EOF'
import sqlite3
try:
    db = sqlite3.connect('/tmp/live_run/sniper.db')
    rows = db.execute('SELECT pnl_rub, reason, hold_sec FROM trades ORDER BY id').fetchall()
    if not rows:
        print('сделок пока нет')
    else:
        n = len(rows); wins = sum(1 for r in rows if r[0] > 0)
        pnl = sum(r[0] for r in rows)
        gw = sum(r[0] for r in rows if r[0] > 0); gl = abs(sum(r[0] for r in rows if r[0] < 0))
        pf = (gw/gl) if gl else float('inf')
        avg_hold = sum(r[2] for r in rows)/n
        print(f"закрыто: {n} | винрейт: {wins}/{n} ({100*wins/n:.0f}%) | PnL: {pnl:+.2f} ₽ | PF: {pf:.2f} | ср. время: {avg_hold:.0f}с")
        from collections import Counter
        c = Counter(r[1] for r in rows)
        for reason, cnt in c.most_common():
            rp = sum(r[0] for r in rows if r[1] == reason)
            print(f"  {reason}: {cnt}× ({rp:+.2f} ₽)")
except Exception as e:
    print('db:', e)
EOF
echo "══════════════════════════════════"
